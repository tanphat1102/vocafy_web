const BASE_URL = "https://vocafy.milize-lena.space/api";

chrome.runtime.onInstalled.addListener(() => {
  console.log("Vocafy Extension installed");
});

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type !== "VOCAFY_SAVE_SELECTION") return;

  (async () => {
    try {
      const accessToken = (await chrome.storage.local.get(["accessToken"])).accessToken;
      if (!accessToken) {
        sendResponse({ ok: false, error: "NO_TOKEN" });
        return;
      }

      const term = String(message?.payload?.term || "").trim();
      if (!term) {
        sendResponse({ ok: false, error: "EMPTY_TERM" });
        return;
      }

      const response = await fetch(`${BASE_URL}/vocabularies/quick`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${accessToken}`,
        },
        body: JSON.stringify({
          term,
          language_code: "EN",
          script_type: "LATIN",
          meaning_text: null,
          part_of_speech: null,
          example_sentence: null,
          example_translation: null,
          note: null,
          sort_order: null,
        }),
      });

      if (response.status === 401) {
        sendResponse({ ok: false, error: "INVALID_TOKEN" });
        return;
      }

      if (!response.ok) {
        const detail = await response.text();
        sendResponse({ ok: false, error: `HTTP_${response.status}`, detail });
        return;
      }

      const data = await response.json().catch(() => null);
      sendResponse({ ok: true, data });
    } catch (error) {
      sendResponse({
        ok: false,
        error: "UNKNOWN",
        detail: error instanceof Error ? error.message : "Unknown error",
      });
    }
  })();

  return true;
});
