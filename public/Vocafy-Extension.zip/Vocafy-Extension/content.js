(() => {
  if (window.__vocafySelectionInitialized) return;
  window.__vocafySelectionInitialized = true;

  const BUTTON_ID = "vocafy-selection-save-btn";
  const TOAST_ID = "vocafy-selection-toast";
  const STYLE_ID = "vocafy-selection-style";
  const MAX_TERM_LENGTH = 80;

  let lastSelection = null;
  let hideTimer = null;
  let isClickingSaveButton = false;

  const injectStyle = () => {
    if (document.getElementById(STYLE_ID)) return;
    const style = document.createElement("style");
    style.id = STYLE_ID;
    style.textContent = `
      #${BUTTON_ID} {
        position: fixed;
        z-index: 2147483647;
        border: 0;
        border-radius: 999px;
        width: 14px;
        height: 14px;
        padding: 0;
        font-size: 10px;
        line-height: 1;
        font-weight: 600;
        color: #ffffff;
        background: #4f46e5;
        box-shadow: 0 6px 20px rgba(79, 70, 229, 0.35);
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
      }
      #${BUTTON_ID}:hover {
        background: #4338ca;
      }
      #${TOAST_ID} {
        position: fixed;
        z-index: 2147483647;
        left: 50%;
        bottom: 16px;
        transform: translateX(-50%);
        border-radius: 999px;
        padding: 8px 12px;
        color: #0f172a;
        background: #ffffff;
        border: 1px solid rgba(15, 23, 42, 0.12);
        box-shadow: 0 10px 20px rgba(15, 23, 42, 0.2);
        font-size: 12px;
        font-weight: 500;
      }
      #${TOAST_ID}.error {
        color: #b91c1c;
        border-color: rgba(220, 38, 38, 0.35);
      }
    `;
    document.documentElement.appendChild(style);
  };

  const getButton = () => document.getElementById(BUTTON_ID);

  const removeButtonOnly = () => {
    const button = getButton();
    if (button) button.remove();
  };

  const hideButton = (clearSelection = true) => {
    removeButtonOnly();
    if (!clearSelection) return;
    lastSelection = null;
  };

  const showToast = (message, isError) => {
    const oldToast = document.getElementById(TOAST_ID);
    if (oldToast) oldToast.remove();

    const toast = document.createElement("div");
    toast.id = TOAST_ID;
    if (isError) toast.classList.add("error");
    toast.textContent = message;
    document.documentElement.appendChild(toast);

    window.setTimeout(() => {
      toast.remove();
    }, 1800);
  };

  const normalizeSelectionText = (text) => text.replace(/\s+/g, " ").trim();

  const readSelection = () => {
    const selection = window.getSelection();
    if (!selection || selection.rangeCount === 0 || selection.isCollapsed) return null;

    const rawText = normalizeSelectionText(selection.toString());
    if (!rawText) return null;
    if (rawText.length > MAX_TERM_LENGTH) return null;

    const range = selection.getRangeAt(0);
    const rect = range.getBoundingClientRect();
    if (!rect || (rect.width === 0 && rect.height === 0)) return null;

    return {
      term: rawText,
      rect: {
        top: rect.top,
        right: rect.right,
        bottom: rect.bottom,
        left: rect.left,
        width: rect.width,
        height: rect.height,
      },
    };
  };

  const placeButton = (button, rect) => {
    const buttonWidth = 14;
    const buttonHeight = 14;
    const left = Math.max(
      8,
      Math.min(window.innerWidth - buttonWidth - 8, rect.right - buttonWidth + 1)
    );
    const top = Math.max(
      8,
      Math.min(window.innerHeight - buttonHeight - 8, rect.top - buttonHeight - 4)
    );
    button.style.left = `${left}px`;
    button.style.top = `${top}px`;
  };

  const saveSelectedTerm = (term) =>
    new Promise((resolve, reject) => {
      chrome.runtime.sendMessage(
        {
          type: "VOCAFY_SAVE_SELECTION",
          payload: { term },
        },
        (response) => {
          if (chrome.runtime.lastError) {
            reject(new Error(chrome.runtime.lastError.message));
            return;
          }
          resolve(response);
        }
      );
    });

  const showButton = (selectionPayload) => {
    removeButtonOnly();

    const button = document.createElement("button");
    button.id = BUTTON_ID;
    button.type = "button";
    button.textContent = "+";
    placeButton(button, selectionPayload.rect);

    button.addEventListener("mousedown", (event) => {
      event.preventDefault();
      event.stopPropagation();
      isClickingSaveButton = true;
      window.setTimeout(() => {
        isClickingSaveButton = false;
      }, 600);
    });

    button.addEventListener("click", async (event) => {
      event.preventDefault();
      event.stopPropagation();
      button.disabled = true;
      button.textContent = "…";

      try {
        const result = await saveSelectedTerm(selectionPayload.term);
        if (result?.ok) {
          showToast(`Saved "${selectionPayload.term}"`, false);
        } else if (result?.error === "NO_TOKEN" || result?.error === "INVALID_TOKEN") {
          showToast("Open Vocafy and sign in first.", true);
        } else {
          showToast("Save failed. Try again.", true);
        }
      } catch (_error) {
        showToast("Save failed. Try again.", true);
      } finally {
        isClickingSaveButton = false;
        hideButton();
      }
    });

    document.documentElement.appendChild(button);
    lastSelection = selectionPayload;
  };

  const syncSelectionButton = (event) => {
    const target = event && event.target instanceof Element ? event.target : null;
    if (target && target.closest(`#${BUTTON_ID}`)) return;
    if (isClickingSaveButton) return;

    if (hideTimer) {
      window.clearTimeout(hideTimer);
      hideTimer = null;
    }

    const payload = readSelection();
    if (!payload) {
      hideTimer = window.setTimeout(hideButton, 120);
      return;
    }

    const button = getButton();
    if (button && lastSelection?.term === payload.term) {
      lastSelection = payload;
      placeButton(button, payload.rect);
      return;
    }

    showButton(payload);
  };

  const reflowButton = () => {
    if (!lastSelection) return;
    const liveSelection = readSelection();
    if (!liveSelection || liveSelection.term !== lastSelection.term) {
      hideButton();
      return;
    }
    const { rect } = liveSelection;
    const outOfViewport =
      rect.bottom < 0 ||
      rect.top > window.innerHeight ||
      rect.right < 0 ||
      rect.left > window.innerWidth;
    if (outOfViewport) {
      hideButton(false);
      return;
    }
    lastSelection = liveSelection;
    const button = getButton();
    if (!button) {
      showButton(liveSelection);
      return;
    }
    placeButton(button, liveSelection.rect);
  };

  injectStyle();
  document.addEventListener("mouseup", syncSelectionButton);
  document.addEventListener("keyup", syncSelectionButton);
  document.addEventListener("selectionchange", syncSelectionButton);
  window.addEventListener("scroll", reflowButton, true);
  window.addEventListener("resize", reflowButton);
})();
